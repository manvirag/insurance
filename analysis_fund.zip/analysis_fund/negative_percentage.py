import json
import pandas as pd
import numpy as np

def analyze_negative_returns(json_file_path, bin_size=5):
    """
    Reads a JSON file containing rolling returns data, flattens nested lists if needed,
    filters negative returns, dynamically bins them, and computes accurate percentages.
    """
    # 1. Load data from JSON file
    with open(json_file_path, 'r') as f:
        data = json.load(f)
    
    # FIX: Handle nested list structure if your JSON looks like [[ {...}, {...} ]]
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], list):
        data = data[0]
    
    df = pd.DataFrame(data)
    
    # Check if 'scheme_rolling_returns' column exists
    if 'scheme_rolling_returns' not in df.columns:
        raise ValueError(f"JSON data columns found: {list(df.columns)}. Missing 'scheme_rolling_returns'.")
    
    # 2. Filter for negative returns only and take their absolute value for binning
    negatives = df[df['scheme_rolling_returns'] < 0]['scheme_rolling_returns'].abs()
    
    total_negative_count = len(negatives)
    if total_negative_count == 0:
        print("No negative returns found in the dataset.")
        return
    
    # 3. Dynamically determine the maximum bin edge based on the minimum value in the data
    max_neg_magnitude = negatives.max()
    max_bin = int(np.ceil(max_neg_magnitude / bin_size) * bin_size)
    
    # Create bin edges (e.g., 0, 5, 10, 15, ... up to max_bin)
    bins = range(0, max_bin + bin_size, bin_size)
    labels = [f"-{bins[i]}% to -{bins[i+1]}%" for i in range(len(bins) - 1)]
    
    # 4. Categorize data into bins
    categories = pd.cut(negatives, bins=bins, labels=labels, right=True, include_lowest=True)
    counts = categories.value_counts().sort_index()
    
    # Calculate exact percentages out of 100% of negative instances
    percentages = (counts / total_negative_count) * 100
    
    # 5. Compile into a clean summary DataFrame
    summary_df = pd.DataFrame({
        'Count': counts,
        'Percentage of Negatives (%)': percentages.round(2)
    })
    
    print(f"--- Negative Return Distribution Analysis ---")
    print(f"Total periods analyzed: {len(df)}")
    print(f"Total negative periods: {total_negative_count} ({round((total_negative_count/len(df))*100, 2)}% of total time)")
    print(f"Maximum drawdown recorded: -{max_neg_magnitude}%\n")
    print(summary_df.to_string())
    
    return summary_df

# === HOW TO RUN ===
summary = analyze_negative_returns('nifty_next_50_tri_20y_1_month_rolling.json')