import json
import pandas as pd
import numpy as np

def analyze_absolute_drawdowns(json_file_path, bin_size=5):
    """
    Calculates the exact distribution and probability of how long the index 
    spent in various drawdown ranges from its all-time high, without any time horizon.
    """
    with open(json_file_path, 'r') as f:
        data = json.load(f)
    
    # Handle nested lists if present
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], list):
        data = data[0]
        
    df = pd.DataFrame(data)
    
    # Convert dates and sort chronologically
    df['nav_date'] = pd.to_datetime(df['nav_date'], format='mixed', errors='coerce')
    df = df.sort_values('nav_date').reset_index(drop=True)
    
    # 1. Calculate running max (all-time peak NAV up to that day)
    df['peak_nav'] = df['scheme_nav'].cummax()
    
    # 2. Calculate percentage distance from the peak (Drawdown)
    df['drawdown_pct'] = ((df['scheme_nav'] - df['peak_nav']) / df['peak_nav']) * 100
    
    # 3. Filter only negative drawdowns (days when the index was below its peak)
    # (Note: Days where drawdown == 0% are days at all-time highs)
    below_peak = df[df['drawdown_pct'] < 0]
    drawdown_magnitudes = below_peak['drawdown_pct'].abs()
    
    total_days = len(df)
    total_days_below_peak = len(below_peak)
    
    if total_days_below_peak == 0:
        print("Index has never been below its peak.")
        return
    
    # 4. Dynamically bin the drawdowns
    max_drawdown = drawdown_magnitudes.max()
    max_bin = int(np.ceil(max_drawdown / bin_size) * bin_size)
    
    bins = range(0, max_bin + bin_size, bin_size)
    labels = [f"-{bins[i]}% to -{bins[i+1]}%" for i in range(len(bins) - 1)]
    
    categories = pd.cut(drawdown_magnitudes, bins=bins, labels=labels, right=True, include_lowest=True)
    counts = categories.value_counts().sort_index()
    
    # Probability out of total days spent below peak
    probabilities = (counts / total_days_below_peak) * 100
    
    summary_df = pd.DataFrame({
        'Days Spent': counts,
        'Probability of Days Below Peak (%)': probabilities.round(2)
    })
    
    print(f"--- Horizon-Free Drawdown Analysis ---")
    print(f"Total Trading Days Analyzed: {total_days}")
    print(f"Days spent at All-Time Highs: {total_days - total_days_below_peak} ({round(((total_days - total_days_below_peak)/total_days)*100, 2)}% of history)")
    print(f"Days spent Below Peak: {total_days_below_peak} ({round((total_days_below_peak/total_days)*100, 2)}% of history)")
    print(f"Worst Historical Drawdown: -{max_drawdown:.2f}%\n")
    print(summary_df.to_string())
    
    return summary_df

# === HOW TO RUN ===
# Pass your daily NAV JSON file here:

print("Smallcap 20y 1y rolling")
result = analyze_absolute_drawdowns('nifty_250_smallcap_tri_20y_1y_rolling.json')
print("--------------------------------")
print("Smallcap 20y 1 month")
result = analyze_absolute_drawdowns('nifty_250_smallcap_tri_1_month_20y.json')
print("--------------------------------")
print("Midcap 20y 1 month")
result = analyze_absolute_drawdowns('nifty_150_midcap_tri_1_month_rolling.json')
print("--------------------------------")

print("Midcap 20y 1 year")
result = analyze_absolute_drawdowns('nifty_150_midcap_tri_1_year_rolling.json')
print("--------------------------------")

print("nifty 50 20y 1 month")
result = analyze_absolute_drawdowns('nifty_50_tri_20y_1_month_rolling.json')
print("--------------------------------")

print("nifty 50 20y 1 year")
result = analyze_absolute_drawdowns('nifty_50_tri_20y_1_year_rolling.json')
print("--------------------------------")

print("Next 50 20y 1 month")
result = analyze_absolute_drawdowns('nifty_next_50_tri_20y_1_month_rolling.json')
